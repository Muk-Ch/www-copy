import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_auth/Screens/Welcome/welcome_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/provider/Bookingprovider.dart';
import 'package:flutter_auth/provider/Historyprovider.dart';
import 'package:provider/provider.dart';
import 'provider/Userporvider.dart';
import 'package:flutter_auth/provider/Lotsprovider.dart';
import 'package:flutter_auth/provider/Transactionprovider.dart';
import 'package:flutter_auth/provider/Omiseprovider.dart';

 String host = "http://192.168.1.157:1542";
//String host = "http://192.168.31.164:1542";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp])
      .then((value) => runApp(MultiProvider(providers: [
            ChangeNotifierProvider(create: (_) => Userprovider()),
            ChangeNotifierProvider(create: (_) => Lotsprovider()),
            ChangeNotifierProvider(create: (_) => Bookingprovider()),
            ChangeNotifierProvider(create: (_) => Transactionprovider()),
            ChangeNotifierProvider(create: (_) => Omiseprovider()),
            ChangeNotifierProvider(create: (_) => Historyprovider())
          ], child: MyApp())));
}

// void main() => runApp(

//   MultiProvider(
//     provider: [],

//     child: MyApp()));

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Auth',
      theme: ThemeData(
        primaryColor: A,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: WelcomeScreen(),
    );
  }
}
