import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/service/bookingservice.dart';
import 'package:flutter_auth/model/BookingModel.dart';

class Bookingprovider extends ChangeNotifier {
  BookingsModel bookingsModel;
  String qrinfoIn;

  Future<bool> bookingAPI(_lotid, _userid) async {
    print('BOOKING API WAS CALL');
    await BookingService(_lotid, _userid).bookingAPI().then((data) {
      if (data.statusCode == 200) {
        bookingsModel = BookingsModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isBookingsModel();
  }

  bool isBookingsModel() {
    return bookingsModel != null ? true : false;
  }
}
