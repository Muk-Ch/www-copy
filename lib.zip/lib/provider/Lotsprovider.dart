import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/service/lotservice.dart';
import 'package:flutter_auth/model/LotsModel.dart';


class Lotsprovider extends ChangeNotifier {
  LotsModel lotsModel;
  

  Future<bool> lots() async {
    await LotsService().lotAPI().then((data) {
      if (data.statusCode == 200) {
        lotsModel = LotsModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isLotsModel();
  }

  bool isLotsModel() {
    return lotsModel != null ? true : false;
  }
}
