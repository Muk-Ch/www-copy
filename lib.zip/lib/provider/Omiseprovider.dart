import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/model/BankModel.dart';
import 'package:flutter_auth/model/SourceModel.dart';
import 'package:flutter_auth/service/omiseservice.dart';
import 'package:flutter_auth/model/TokensModel.dart';
import 'package:flutter_auth/model/ChargesModel.dart';
//import 'package:flutter_auth/service/lotservice.dart';
//import 'package:flutter_auth/model/LotsModel.dart';

class Omiseprovider extends ChangeNotifier {
  String cardName;
  String cardNumber;
  String cardCode;
  List<String> cardExpired;
  String type;


  TokensModel tokensModel;
  ChargesModel chargesModel;
  SourceModel sourceModel;
  BankModel bankModel;

  //   "card[name]": "JOHN DOE",
  // "card[number]": "4242424242424242",
  // "card[security_code]": "123",
  // "card[expiration_month]": "3",
  // "card[expiration_year]": "2023"

  //LotsModel lotsModel;

  Future<bool> tokensAPI() async {
    await TokensService(
            cardName, cardNumber, cardCode, cardExpired[0], cardExpired[1])
        .tokensAPI()
        .then((data) {
      if (data.statusCode == 200) {
        tokensModel = TokensModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isTokensModel();
  }

  bool isTokensModel() {
    return tokensModel != null ? true : false;
  }

  Future<bool> chargeAPI(_bookingId, _amount, _tokenId) async {
    print("CHARGE WAS CALL");
    await ChargesService(_bookingId, _amount, _tokenId)
        .chargeAPI()
        .then((data) {
      if (data.statusCode == 200) {
        print("CHARGE SUCCESS");
        chargesModel = ChargesModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isChargesModel();
  }

  bool isChargesModel() {
    return chargesModel != null ? true : false;
  }

  Future<bool> sourceAPI(_bookingId, _amount, _type) async {
    await SourceService(_bookingId, _amount, _type)
        .sourceAPI()
        .then((data) {
      if (data.statusCode == 200) {
        sourceModel = SourceModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isSourceModel();
  }

  bool isSourceModel() {
    return sourceModel != null ? true : false;
  }

  Future<bool> bankAPI(_bookingId, _amount, _source) async {
    await BankService(
            _bookingId, _amount, _source)
        .bankAPI()
        .then((data) {
      if (data.statusCode == 200) {
        bankModel = BankModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isBankModel();
  }

  bool isBankModel() {
    return bankModel != null ? true : false;
  }
}


