import 'dart:convert';
import 'package:flutter_auth/model/LoginModel.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/service/userservice.dart';
import 'package:flutter_auth/model/SignModel.dart';


class Userprovider extends ChangeNotifier {
  LoginModel loginModel;
  SignModel signModel;

  Future<bool> login(_username, _password) async {
    await LoginService(_username, _password).loginAPI().then((data) {
      if (data.statusCode == 200) {
        loginModel = LoginModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isLoginModel();
  }

  bool isLoginModel() {
    return loginModel != null ? true : false;
  }

  Future<bool> sign(_username, _password,_email,_phoneno) async {
    await SignService(_username, _password,_email,_phoneno).signAPI().then((data) {
      if (data.statusCode == 200) {
        signModel = SignModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isSignModel();
  }

  bool isSignModel() {
    return signModel != null ? true : false;
  }  
}
