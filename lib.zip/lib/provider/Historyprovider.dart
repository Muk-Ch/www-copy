import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/model/HistoryModel.dart';
import 'package:flutter_auth/service/historyservice.dart';

class Historyprovider extends ChangeNotifier {
  HistoryModel historyModel;
 

  Future<bool> historyAPI(_userid) async {
    await HistoryService(_userid).historyAPI().then((data) {
      if (data.statusCode == 200) {
        
        historyModel = HistoryModel.fromJson(json.decode(data.body));
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isHistoryModel();
  }

  bool isHistoryModel() {
    return historyModel != null ? true : false;
  }

  
    

  }

