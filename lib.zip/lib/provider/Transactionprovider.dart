import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_auth/model/PaymentModel.dart';
import 'package:flutter_auth/model/UnpaidModel.dart';
import 'package:flutter_auth/service/transectionservice.dart';

class Transactionprovider extends ChangeNotifier {
  UnpaidModel unpaidModel;
  PaymentModel paymentModel;
  DateTime CheckoutTime ;
  var total;// = CheckoutTime.difference(DateTime.parse(unpaidModel.response[0].timeIn)).inDays;
  var amount;
  String qrinfoOut;

  Future<bool> unpaidAPI(_userid) async {
    await UnpaidService(_userid).unpaidAPI().then((data) {
      if (data.statusCode == 200) {
        print("UNPAID WAS CALL");
        unpaidModel = UnpaidModel.fromJson(json.decode(data.body));
        print(unpaidModel.response[0].timeIn);
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isUnpaidModel();
  }

  bool isUnpaidModel() {
    return unpaidModel != null ? true : false;
  }

  Future<bool> paymentAPI(_bookindId, _price) async {
    await PaymentService(_bookindId, _price).paymentAPI().then((data) {
      if (data.statusCode == 200) {
        print("PAYMENT SUCCESS");
        paymentModel = PaymentModel.fromJson(json.decode(data.body));
       
      } else {
        print(data.statusCode);
      }
    }).catchError((error) {
      print('error : $error');
    });

    return isPaymentModel();
  }

  bool isPaymentModel() {
    return paymentModel != null ? true : false;
  }

  
    

  }

