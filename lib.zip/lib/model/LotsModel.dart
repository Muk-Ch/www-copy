// To parse this JSON data, do
//
//     final lotsModel = lotsModelFromJson(jsonString);

import 'dart:convert';

LotsModel lotsModelFromJson(String str) => LotsModel.fromJson(json.decode(str));

String lotsModelToJson(LotsModel data) => json.encode(data.toJson());

class LotsModel {
    LotsModel({
        this.status,
        this.response,
    });

    bool status;
    List<Response> response;

    factory LotsModel.fromJson(Map<String, dynamic> json) => LotsModel(
        status: json["status"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
    };
}

class Response {
    Response({
        this.lotId,
        this.status,
        this.updateDatetime,
    });

    int lotId;
    bool status;
    DateTime updateDatetime;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        lotId: json["LotId"],
        status: json["Status"],
        updateDatetime: DateTime.parse(json["UpdateDatetime"]),
    );

    Map<String, dynamic> toJson() => {
        "LotId": lotId,
        "Status": status,
        "UpdateDatetime": updateDatetime.toIso8601String(),
    };
}
