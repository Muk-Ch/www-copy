// To parse this JSON data, do
//
//     final chargesModel = chargesModelFromJson(jsonString);

import 'dart:convert';

ChargesModel chargesModelFromJson(String str) => ChargesModel.fromJson(json.decode(str));

String chargesModelToJson(ChargesModel data) => json.encode(data.toJson());

class ChargesModel {
    ChargesModel({
        this.object,
        this.id,
        this.location,
        this.amount,
        this.net,
        this.fee,
        this.feeVat,
        this.interest,
        this.interestVat,
        this.fundingAmount,
        this.refundedAmount,
        this.authorized,
        this.capturable,
        this.capture,
        this.disputable,
        this.livemode,
        this.refundable,
        this.reversed,
        this.reversible,
        this.voided,
        this.paid,
        this.expired,
        this.platformFee,
        this.currency,
        this.fundingCurrency,
        this.ip,
        this.refunds,
        this.link,
        this.description,
        this.metadata,
        this.card,
        this.source,
        this.schedule,
        this.customer,
        this.dispute,
        this.transaction,
        this.failureCode,
        this.failureMessage,
        this.status,
        this.authorizeUri,
        this.returnUri,
        this.createdAt,
        this.paidAt,
        this.expiresAt,
        this.expiredAt,
        this.reversedAt,
        this.zeroInterestInstallments,
        this.branch,
        this.terminal,
        this.device,
    });

    String object;
    String id;
    String location;
    int amount;
    int net;
    int fee;
    int feeVat;
    int interest;
    int interestVat;
    int fundingAmount;
    int refundedAmount;
    bool authorized;
    bool capturable;
    bool capture;
    bool disputable;
    bool livemode;
    bool refundable;
    bool reversed;
    bool reversible;
    bool voided;
    bool paid;
    bool expired;
    PlatformFee platformFee;
    String currency;
    String fundingCurrency;
    dynamic ip;
    Refunds refunds;
    dynamic link;
    dynamic description;
    Metadata metadata;
    Card card;
    dynamic source;
    dynamic schedule;
    dynamic customer;
    dynamic dispute;
    String transaction;
    dynamic failureCode;
    dynamic failureMessage;
    String status;
    dynamic authorizeUri;
    dynamic returnUri;
    DateTime createdAt;
    DateTime paidAt;
    DateTime expiresAt;
    dynamic expiredAt;
    dynamic reversedAt;
    bool zeroInterestInstallments;
    dynamic branch;
    dynamic terminal;
    dynamic device;

    factory ChargesModel.fromJson(Map<String, dynamic> json) => ChargesModel(
        object: json["object"],
        id: json["id"],
        location: json["location"],
        amount: json["amount"],
        net: json["net"],
        fee: json["fee"],
        feeVat: json["fee_vat"],
        interest: json["interest"],
        interestVat: json["interest_vat"],
        fundingAmount: json["funding_amount"],
        refundedAmount: json["refunded_amount"],
        authorized: json["authorized"],
        capturable: json["capturable"],
        capture: json["capture"],
        disputable: json["disputable"],
        livemode: json["livemode"],
        refundable: json["refundable"],
        reversed: json["reversed"],
        reversible: json["reversible"],
        voided: json["voided"],
        paid: json["paid"],
        expired: json["expired"],
        platformFee: PlatformFee.fromJson(json["platform_fee"]),
        currency: json["currency"],
        fundingCurrency: json["funding_currency"],
        ip: json["ip"],
        refunds: Refunds.fromJson(json["refunds"]),
        link: json["link"],
        description: json["description"],
        metadata: Metadata.fromJson(json["metadata"]),
        card: Card.fromJson(json["card"]),
        source: json["source"],
        schedule: json["schedule"],
        customer: json["customer"],
        dispute: json["dispute"],
        transaction: json["transaction"],
        failureCode: json["failure_code"],
        failureMessage: json["failure_message"],
        status: json["status"],
        authorizeUri: json["authorize_uri"],
        returnUri: json["return_uri"],
        createdAt: DateTime.parse(json["created_at"]),
        paidAt: DateTime.parse(json["paid_at"]),
        expiresAt: DateTime.parse(json["expires_at"]),
        expiredAt: json["expired_at"],
        reversedAt: json["reversed_at"],
        zeroInterestInstallments: json["zero_interest_installments"],
        branch: json["branch"],
        terminal: json["terminal"],
        device: json["device"],
    );

    Map<String, dynamic> toJson() => {
        "object": object,
        "id": id,
        "location": location,
        "amount": amount,
        "net": net,
        "fee": fee,
        "fee_vat": feeVat,
        "interest": interest,
        "interest_vat": interestVat,
        "funding_amount": fundingAmount,
        "refunded_amount": refundedAmount,
        "authorized": authorized,
        "capturable": capturable,
        "capture": capture,
        "disputable": disputable,
        "livemode": livemode,
        "refundable": refundable,
        "reversed": reversed,
        "reversible": reversible,
        "voided": voided,
        "paid": paid,
        "expired": expired,
        "platform_fee": platformFee.toJson(),
        "currency": currency,
        "funding_currency": fundingCurrency,
        "ip": ip,
        "refunds": refunds.toJson(),
        "link": link,
        "description": description,
        "metadata": metadata.toJson(),
        "card": card.toJson(),
        "source": source,
        "schedule": schedule,
        "customer": customer,
        "dispute": dispute,
        "transaction": transaction,
        "failure_code": failureCode,
        "failure_message": failureMessage,
        "status": status,
        "authorize_uri": authorizeUri,
        "return_uri": returnUri,
        "created_at": createdAt.toIso8601String(),
        "paid_at": paidAt.toIso8601String(),
        "expires_at": expiresAt.toIso8601String(),
        "expired_at": expiredAt,
        "reversed_at": reversedAt,
        "zero_interest_installments": zeroInterestInstallments,
        "branch": branch,
        "terminal": terminal,
        "device": device,
    };
}

class Card {
    Card({
        this.object,
        this.id,
        this.livemode,
        this.location,
        this.deleted,
        this.street1,
        this.street2,
        this.city,
        this.state,
        this.phoneNumber,
        this.postalCode,
        this.country,
        this.financing,
        this.bank,
        this.brand,
        this.fingerprint,
        this.firstDigits,
        this.lastDigits,
        this.name,
        this.expirationMonth,
        this.expirationYear,
        this.securityCodeCheck,
        this.createdAt,
    });

    String object;
    String id;
    bool livemode;
    dynamic location;
    bool deleted;
    dynamic street1;
    dynamic street2;
    dynamic city;
    dynamic state;
    dynamic phoneNumber;
    dynamic postalCode;
    String country;
    String financing;
    String bank;
    String brand;
    String fingerprint;
    dynamic firstDigits;
    String lastDigits;
    String name;
    int expirationMonth;
    int expirationYear;
    bool securityCodeCheck;
    DateTime createdAt;

    factory Card.fromJson(Map<String, dynamic> json) => Card(
        object: json["object"],
        id: json["id"],
        livemode: json["livemode"],
        location: json["location"],
        deleted: json["deleted"],
        street1: json["street1"],
        street2: json["street2"],
        city: json["city"],
        state: json["state"],
        phoneNumber: json["phone_number"],
        postalCode: json["postal_code"],
        country: json["country"],
        financing: json["financing"],
        bank: json["bank"],
        brand: json["brand"],
        fingerprint: json["fingerprint"],
        firstDigits: json["first_digits"],
        lastDigits: json["last_digits"],
        name: json["name"],
        expirationMonth: json["expiration_month"],
        expirationYear: json["expiration_year"],
        securityCodeCheck: json["security_code_check"],
        createdAt: DateTime.parse(json["created_at"]),
    );

    Map<String, dynamic> toJson() => {
        "object": object,
        "id": id,
        "livemode": livemode,
        "location": location,
        "deleted": deleted,
        "street1": street1,
        "street2": street2,
        "city": city,
        "state": state,
        "phone_number": phoneNumber,
        "postal_code": postalCode,
        "country": country,
        "financing": financing,
        "bank": bank,
        "brand": brand,
        "fingerprint": fingerprint,
        "first_digits": firstDigits,
        "last_digits": lastDigits,
        "name": name,
        "expiration_month": expirationMonth,
        "expiration_year": expirationYear,
        "security_code_check": securityCodeCheck,
        "created_at": createdAt.toIso8601String(),
    };
}

class Metadata {
    Metadata();

    factory Metadata.fromJson(Map<String, dynamic> json) => Metadata(
    );

    Map<String, dynamic> toJson() => {
    };
}

class PlatformFee {
    PlatformFee({
        this.fixed,
        this.amount,
        this.percentage,
    });

    dynamic fixed;
    dynamic amount;
    dynamic percentage;

    factory PlatformFee.fromJson(Map<String, dynamic> json) => PlatformFee(
        fixed: json["fixed"],
        amount: json["amount"],
        percentage: json["percentage"],
    );

    Map<String, dynamic> toJson() => {
        "fixed": fixed,
        "amount": amount,
        "percentage": percentage,
    };
}

class Refunds {
    Refunds({
        this.object,
        this.data,
        this.limit,
        this.offset,
        this.total,
        this.location,
        this.order,
        this.from,
        this.to,
    });

    String object;
    List<dynamic> data;
    int limit;
    int offset;
    int total;
    String location;
    String order;
    DateTime from;
    DateTime to;

    factory Refunds.fromJson(Map<String, dynamic> json) => Refunds(
        object: json["object"],
        data: List<dynamic>.from(json["data"].map((x) => x)),
        limit: json["limit"],
        offset: json["offset"],
        total: json["total"],
        location: json["location"],
        order: json["order"],
        from: DateTime.parse(json["from"]),
        to: DateTime.parse(json["to"]),
    );

    Map<String, dynamic> toJson() => {
        "object": object,
        "data": List<dynamic>.from(data.map((x) => x)),
        "limit": limit,
        "offset": offset,
        "total": total,
        "location": location,
        "order": order,
        "from": from.toIso8601String(),
        "to": to.toIso8601String(),
    };
}
