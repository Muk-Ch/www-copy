// To parse this JSON data, do
//
//     final sourceModel = sourceModelFromJson(jsonString);

import 'dart:convert';

SourceModel sourceModelFromJson(String str) => SourceModel.fromJson(json.decode(str));

String sourceModelToJson(SourceModel data) => json.encode(data.toJson());

class SourceModel {
    SourceModel({
        this.object,
        this.id,
        this.livemode,
        this.location,
        this.amount,
        this.barcode,
        this.bank,
        this.createdAt,
        this.currency,
        this.email,
        this.flow,
        this.installmentTerm,
        this.name,
        this.mobileNumber,
        this.phoneNumber,
        this.scannableCode,
        this.references,
        this.storeId,
        this.storeName,
        this.terminalId,
        this.type,
        this.zeroInterestInstallments,
        this.chargeStatus,
        this.receiptAmount,
        this.discounts,
    });

    String object;
    String id;
    bool livemode;
    String location;
    int amount;
    dynamic barcode;
    dynamic bank;
    DateTime createdAt;
    String currency;
    dynamic email;
    String flow;
    dynamic installmentTerm;
    dynamic name;
    dynamic mobileNumber;
    dynamic phoneNumber;
    dynamic scannableCode;
    dynamic references;
    dynamic storeId;
    dynamic storeName;
    dynamic terminalId;
    String type;
    dynamic zeroInterestInstallments;
    String chargeStatus;
    dynamic receiptAmount;
    List<dynamic> discounts;

    factory SourceModel.fromJson(Map<String, dynamic> json) => SourceModel(
        object: json["object"],
        id: json["id"],
        livemode: json["livemode"],
        location: json["location"],
        amount: json["amount"],
        barcode: json["barcode"],
        bank: json["bank"],
        createdAt: DateTime.parse(json["created_at"]),
        currency: json["currency"],
        email: json["email"],
        flow: json["flow"],
        installmentTerm: json["installment_term"],
        name: json["name"],
        mobileNumber: json["mobile_number"],
        phoneNumber: json["phone_number"],
        scannableCode: json["scannable_code"],
        references: json["references"],
        storeId: json["store_id"],
        storeName: json["store_name"],
        terminalId: json["terminal_id"],
        type: json["type"],
        zeroInterestInstallments: json["zero_interest_installments"],
        chargeStatus: json["charge_status"],
        receiptAmount: json["receipt_amount"],
        discounts: List<dynamic>.from(json["discounts"].map((x) => x)),
    );

    Map<String, dynamic> toJson() => {
        "object": object,
        "id": id,
        "livemode": livemode,
        "location": location,
        "amount": amount,
        "barcode": barcode,
        "bank": bank,
        "created_at": createdAt.toIso8601String(),
        "currency": currency,
        "email": email,
        "flow": flow,
        "installment_term": installmentTerm,
        "name": name,
        "mobile_number": mobileNumber,
        "phone_number": phoneNumber,
        "scannable_code": scannableCode,
        "references": references,
        "store_id": storeId,
        "store_name": storeName,
        "terminal_id": terminalId,
        "type": type,
        "zero_interest_installments": zeroInterestInstallments,
        "charge_status": chargeStatus,
        "receipt_amount": receiptAmount,
        "discounts": List<dynamic>.from(discounts.map((x) => x)),
    };
}
