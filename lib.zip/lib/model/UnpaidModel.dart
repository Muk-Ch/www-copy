// To parse this JSON data, do
//
//     final unpaidModel = unpaidModelFromJson(jsonString);

import 'dart:convert';

UnpaidModel unpaidModelFromJson(String str) => UnpaidModel.fromJson(json.decode(str));

String unpaidModelToJson(UnpaidModel data) => json.encode(data.toJson());

class UnpaidModel {
    UnpaidModel({
        this.status,
        this.response,
    });

    bool status;
    List<Response> response;

    factory UnpaidModel.fromJson(Map<String, dynamic> json) => UnpaidModel(
        status: json["status"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
    };
}

class Response {
    Response({
        this.bookingId,
        this.bookingStatus,
        this.updateDatetime,
        this.paymentStatus,
        this.timeIn,
        this.timeOut,
        this.userId,
        this.lotId,
        this.bookingDatetime,
    });

    int bookingId;
    bool bookingStatus;
    DateTime updateDatetime;
    bool paymentStatus;
    String timeIn;
    String timeOut;
    int userId;
    int lotId;
    DateTime bookingDatetime;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        bookingId: json["BookingId"],
        bookingStatus: json["BookingStatus"],
        updateDatetime: DateTime.parse(json["UpdateDatetime"]),
        paymentStatus: json["PaymentStatus"],
        timeIn: json["TimeIn"],
        timeOut: json["TimeOut"],
        userId: json["UserId"],
        lotId: json["LotId"],
        bookingDatetime: DateTime.parse(json["BookingDatetime"]),
    );

    Map<String, dynamic> toJson() => {
        "BookingId": bookingId,
        "BookingStatus": bookingStatus,
        "UpdateDatetime": updateDatetime.toIso8601String(),
        "PaymentStatus": paymentStatus,
        "TimeIn": timeIn,
        "TimeOut": timeOut,
        "UserId": userId,
        "LotId": lotId,
        "BookingDatetime": bookingDatetime.toIso8601String(),
    };
}
