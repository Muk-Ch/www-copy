// To parse this JSON data, do
//
//     final signModel = signModelFromJson(jsonString);

import 'dart:convert';

SignModel signModelFromJson(String str) => SignModel.fromJson(json.decode(str));

String signModelToJson(SignModel data) => json.encode(data.toJson());

class SignModel {
    SignModel({
        this.status,
        this.response,
    });

    bool status;
    String response;

    factory SignModel.fromJson(Map<String, dynamic> json) => SignModel(
        status: json["status"],
        response: json["response"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": response,
    };
}
