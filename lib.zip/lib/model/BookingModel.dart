// To parse this JSON data, do
//
//     final bookingsModel = bookingsModelFromJson(jsonString);

import 'dart:convert';

BookingsModel bookingsModelFromJson(String str) => BookingsModel.fromJson(json.decode(str));

String bookingsModelToJson(BookingsModel data) => json.encode(data.toJson());

class BookingsModel {
    BookingsModel({
        this.status,
        this.response,
    });

    bool status;
    List<Response> response;

    factory BookingsModel.fromJson(Map<String, dynamic> json) => BookingsModel(
        status: json["status"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
    };
}

class Response {
    Response({
        this.bookingId,
        this.lotId,
        this.userId,
        this.bookingDatetime,
        this.bookingStatus,
        this.updateDatetime,
        this.paymentStatus,
        this.timeIn,
        this.timeOut,
    });

    int bookingId;
    int lotId;
    int userId;
    DateTime bookingDatetime;
    bool bookingStatus;
    DateTime updateDatetime;
    bool paymentStatus;
    dynamic timeIn;
    dynamic timeOut;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        bookingId: json["BookingId"],
        lotId: json["LotId"],
        userId: json["UserId"],
        bookingDatetime: DateTime.parse(json["BookingDatetime"]),
        bookingStatus: json["BookingStatus"],
        updateDatetime: DateTime.parse(json["UpdateDatetime"]),
        paymentStatus: json["PaymentStatus"],
        timeIn: json["TimeIn"],
        timeOut: json["TimeOut"],
    );

    Map<String, dynamic> toJson() => {
        "BookingId": bookingId,
        "LotId": lotId,
        "UserId": userId,
        "BookingDatetime": bookingDatetime.toIso8601String(),
        "BookingStatus": bookingStatus,
        "UpdateDatetime": updateDatetime.toIso8601String(),
        "PaymentStatus": paymentStatus,
        "TimeIn": timeIn,
        "TimeOut": timeOut,
    };
}
