// To parse this JSON data, do
//
//     final loginModel = loginModelFromJson(jsonString);

import 'dart:convert';

LoginModel loginModelFromJson(String str) => LoginModel.fromJson(json.decode(str));

String loginModelToJson(LoginModel data) => json.encode(data.toJson());

class LoginModel {
    LoginModel({
        this.status,
        this.response,
        this.length,
    });

    bool status;
    List<Response> response;
    int length;

    factory LoginModel.fromJson(Map<String, dynamic> json) => LoginModel(
        status: json["status"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
        length: json["length"],
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
        "length": length,
    };
}

class Response {
    Response({
        this.userId,
        this.email,
        this.password,
        this.username,
        this.phoneNo,
    });

    int userId;
    String email;
    String password;
    String username;
    String phoneNo;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        userId: json["UserId"],
        email: json["Email"],
        password: json["Password"],
        username: json["Username"],
        phoneNo: json["PhoneNo"],
    );

    Map<String, dynamic> toJson() => {
        "UserId": userId,
        "Email": email,
        "Password": password,
        "Username": username,
        "PhoneNo": phoneNo,
    };
}
