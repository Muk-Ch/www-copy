// To parse this JSON data, do
//
//     final historyModel = historyModelFromJson(jsonString);

import 'dart:convert';

HistoryModel historyModelFromJson(String str) => HistoryModel.fromJson(json.decode(str));

String historyModelToJson(HistoryModel data) => json.encode(data.toJson());

class HistoryModel {
    HistoryModel({
        this.status,
        this.response,
    });

    bool status;
    List<Response> response;

    factory HistoryModel.fromJson(Map<String, dynamic> json) => HistoryModel(
        status: json["status"],
        response: List<Response>.from(json["response"].map((x) => Response.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "status": status,
        "response": List<dynamic>.from(response.map((x) => x.toJson())),
    };
}

class Response {
    Response({
        this.bookingDatetime,
        this.bookingId,
        this.bookingStatus,
        this.timeIn,
        this.timeOut,
        this.paymentStatus,
    });

    DateTime bookingDatetime;
    int bookingId;
    bool bookingStatus;
    String timeIn;
    String timeOut;
    bool paymentStatus;

    factory Response.fromJson(Map<String, dynamic> json) => Response(
        bookingDatetime: DateTime.parse(json["BookingDatetime"]),
        bookingId: json["BookingId"],
        bookingStatus: json["BookingStatus"],
        timeIn: json["TimeIn"],
        timeOut: json["TimeOut"],
        paymentStatus: json["PaymentStatus"],
    );

    Map<String, dynamic> toJson() => {
        "BookingDatetime": bookingDatetime.toIso8601String(),
        "BookingId": bookingId,
        "BookingStatus": bookingStatus,
        "TimeIn": timeIn,
        "TimeOut": timeOut,
        "PaymentStatus": paymentStatus,
    };
}
