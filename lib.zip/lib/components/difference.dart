import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:slide_countdown_clock/slide_countdown_clock.dart';

void main()=> runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Demo(),
    );
  }
}

class Demo extends StatefulWidget {
  
  @override
  _DemoState createState() => _DemoState();
}

class _DemoState extends State<Demo> {
    var now = DateTime.now();
    var NewDay = DateTime.utc(2000, 03, 09);
 
  
  @override
  Widget build(BuildContext context) {
    
      return  Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height:50),
            Padding(padding: EdgeInsets.all(10),
            child: SlideCountdownClock(
                duration: Duration( minutes: 30, seconds: 0),
              shouldShowDays: true,
              slideDirection: SlideDirection.Up,
              separator: ':',
              textStyle: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
             
            ),
            )
            
            
          ],
        ),
      );
    
  }
}