import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:slide_countdown_clock/slide_countdown_clock.dart';

void main()=> runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Clock(),
    );
  }
}

class Clock extends StatefulWidget {
  
  @override
  _ClockState createState() => _ClockState();
}

class _ClockState extends State<Clock> {
  
  
  @override
  Widget build(BuildContext context) {
    
      return  Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(height:50),
            Padding(padding: EdgeInsets.all(10),
            child: SlideCountdownClock(
                duration: Duration( minutes: 5, seconds: 0),
              shouldShowDays: true,
              slideDirection: SlideDirection.Up,
              separator: ':',
              textStyle: TextStyle(
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
              ),
             onDone: (){
               showDialog(
                 context: context,
                 builder: (context){
                   return AlertDialog(
                  title: Text('QR Code',
                 style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                    color: Colors.indigo.shade900,
                    fontFamily: "Asap"
                      ),
                       ),
                 content: Text('   Your qr code is expired.',
                 style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                    color: Colors.black,
                    fontFamily: "Asap"
                      ),
                       ),
                 actions: [
                    FlatButton(
                      child: Text('OK',
                      style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 17,
                    color: Colors.blue,
                    fontFamily: "Asap"
                      ),
                       ),
                      onPressed: () {
                  Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                       return MenuScreen();
                    },
                  ),
                );
              },)
                 ],
               );
                 },
                 );
             },
            ),
            )
            
            
          ],
        ),
      );
    
  }
}