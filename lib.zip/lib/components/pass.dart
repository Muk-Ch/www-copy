import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class RoundedpassField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const RoundedpassField({
    Key key,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      width: 300,
      child: TextField(
        obscureText: true,
        onChanged: onChanged,
        cursorColor: A,
        decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.black,
              width: 2 )
          ),
          hintText: "Password",
          prefixIcon: Icon(
            Icons.lock,
            color: B,
          ),
          suffixIcon: Icon(
            Icons.visibility,
            color: B,
          ),
        ),
        
      ),
      
    );
  }
}
