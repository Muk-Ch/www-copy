import 'package:flutter/material.dart';
import 'package:flutter_auth/components/text_field_container.dart';
import 'package:flutter_auth/constants.dart';

class RoundedloginField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const RoundedloginField({
    Key key,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFieldContainer(
      child: TextField(
        //controller: _controller,
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText: "Username",
          prefixIcon: Icon(
            Icons.person,
            color: B,
          ),
          border: InputBorder.none,
        ),
      ),
    );
  }
}
