import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class RoundedphoneField extends StatelessWidget {
  final ValueChanged<String> onChanged;
  const RoundedphoneField({
    Key key,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      width: 300,
      child: TextField(
        
        onChanged: onChanged,
        cursorColor: A,
        decoration: InputDecoration(
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(
              color: Colors.black,
              width: 2 )
          ),
          hintText: "Phone Number",
          prefixIcon: Icon(
            Icons.phone,
            color: B,
          ),
        ),
        
      ),
      
    );
  }
}
