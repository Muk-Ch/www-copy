import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/payment_method/body.dart';



class MedthodScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(""),
      ),
      
      body: Body(),
      
    );
    
  }
}
