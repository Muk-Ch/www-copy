import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/banking/Medthod_Screen.dart';
import 'package:flutter_auth/Screens/payment_method/background.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/visa/visa_screen.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
                width: 325,
                height: 100,
                // decoration: BoxDecoration(
                //   color: Colors.white,
                //   border: Border(
                //       top: BorderSide(color: Colors.black26, width: 5),
                //       left: BorderSide(color: Colors.black26, width: 5),
                //       right: BorderSide(color: Colors.black26, width: 5)),
                // ),
                child: Card(
                  child: InkWell(
                      highlightColor: H,
                      splashColor: H,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return VisaScreen();
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Icon(
                            Icons.credit_card_rounded,
                            color: A,
                            size: 80,
                          ),
                          Text(
                            "     Credit card             ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black87,
                                fontFamily: "Asap"),
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 40,
                          )
                        ],
                      )),
                )),
            Container(
              width: 325,
              height: 100,
              // decoration: BoxDecoration(
              //   color: Colors.white,
              //   border: Border(
              //       top: BorderSide(color: Colors.black26, width: 5),
              //       left: BorderSide(color: Colors.black26, width: 5),
              //       right: BorderSide(color: Colors.black26, width: 5),
              //       bottom: BorderSide(color: Colors.black26, width: 5)),
              // ),
              child: Card(
              child: InkWell(
                  highlightColor: H,
                  splashColor: H,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) {
                          return BankingScreen();
                        },
                      ),
                    );
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Icon(
                        Icons.account_balance_rounded,
                        color: A,
                        size: 80,
                      ),
                      Text(
                        "   Internet banking   ",
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: Colors.black87,
                            fontFamily: "Asap"),
                      ),
                      Icon(
                        Icons.arrow_forward_ios_rounded,
                        size: 40,
                      )
                    ],
                  )),
              )
            ),
            SizedBox(height: size.height * 0.3),
          ],
        ),
      ),
    );
  }
}
