import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/qr_code_in/body.dart';



class QrScreen extends StatelessWidget {
  final String data = "123";
  @override
  Widget build(BuildContext context) {

    return Scaffold(
     
      body: Body(),

    );
    
  }
}
