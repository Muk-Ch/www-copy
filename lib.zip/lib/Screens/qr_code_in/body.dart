import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/components/clock.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/provider/Bookingprovider.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

class Body extends StatelessWidget {
  //var data = Provider.of<Bookingprovider>(context, listen: false).qrinfoIn;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
        height: size.height,
        width: double.infinity,
        child: Stack(alignment: Alignment.center, children: <Widget>[
          Positioned(
            top: 50,
            left: 30,
            child: IconButton(
              icon: Icon(Icons.home_rounded),
              color: B,
              iconSize: 50,
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return MenuScreen();
                    },
                  ),
                );
              },
            ),
          ),
          Positioned(
              top: 110,
              child: AnimatedContainer(
                duration: Duration(milliseconds: 400),
                child: QrImage(
                  data: Provider.of<Bookingprovider>(context, listen: false)
                      .qrinfoIn,
                  size: 350,
                ),
              )),
          Padding(
            padding: EdgeInsets.all(10),
            child: Demo(),
          ),
          Positioned(
            bottom: 280,
            child: Container(
                width: 250,
                height: 75,
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                    border: Border.all(color: A, width: 5)),
                child: Center(
                  child: Text(
                    "Let's Go !!!",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 30,
                        color: B,
                        fontFamily: "Asap"),
                  ),
                )),
          ),
          Positioned(
            bottom: 0,
            child: Image.asset(
              "assets/images/undraw_super_thank_you_obwk.png",
              height: 280,
              width: 300,
            ),
          ),
        ]));
  }
}
