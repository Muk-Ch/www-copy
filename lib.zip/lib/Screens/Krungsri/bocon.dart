import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Krungsri/bcon.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/Screens/qr_code_out/qr_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/provider/Omiseprovider.dart';
import 'package:flutter_auth/provider/Transactionprovider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            SizedBox(height: size.height * 0.09),
            Text(
              "Confirm your payment",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 25,
                  color: J,
                  fontFamily: "Asap"),
            ),
            SizedBox(height: size.height * 0.09),
            Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                    Provider.of<Transactionprovider>(context, listen: false)
                        .amount
                        .toString(),
                    style: TextStyle(
                        fontSize: 50,
                        fontFamily: "Asap",
                        fontWeight: FontWeight.bold,
                        color: J))),
            Container(
              child: Text('THB',
                  style: TextStyle(
                      fontSize: 50,
                      fontFamily: "Asap",
                      fontWeight: FontWeight.bold,
                      color: Colors.black54)),
            ),
            SizedBox(height: size.height * 0.09),
            Container(
                child: Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FlatButton(
                    padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
                    child: Text("Confirm",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    textColor: K,
                    color: J,
                    shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white, width: 3),
                        borderRadius: BorderRadius.circular(10)),
                    onPressed: () {
                      AwesomeDialog(
                          context: context,
                          dialogType: DialogType.WARNING,
                          headerAnimationLoop: false,
                          animType: AnimType.TOPSLIDE,
                          showCloseIcon: true,
                          closeIcon: Icon(Icons.close_fullscreen_outlined),
                          title: 'QR Code',
                          desc:
                              'QR code for open the gate will be counted immedietly after confirm button pressed.\nTo prevent qr code expired please press confirm button at the gate.',
                          btnCancelOnPress: () {},
                          btnOkOnPress: () {
                            showDialog(
                                context: context,
                                builder: (_) => new CupertinoAlertDialog(
                                      title: new Text("Waiting"),
                                      content: new Text(
                                          "Sending infomation. Please wait."),
                                    ));
                            Provider.of<Omiseprovider>(context, listen: false)
                                .type = "internet_banking_bay";
                            Provider.of<Omiseprovider>(context, listen: false)
                                .sourceAPI(
                                    Provider.of<Transactionprovider>(context,
                                            listen: false)
                                        .unpaidModel
                                        .response[0]
                                        .bookingId,
                                    Provider.of<Transactionprovider>(context,
                                                listen: false)
                                            .amount *
                                        100,
                                    Provider.of<Omiseprovider>(context,
                                            listen: false)
                                        .type)
                                .then((value) => {
                                      if (value == true)
                                        {
                                          print(Provider.of<Omiseprovider>(
                                                  context,
                                                  listen: false)
                                              .sourceModel
                                              .id),
                                          Provider.of<Omiseprovider>(context,
                                                  listen: false)
                                              .bankAPI(
                                                Provider.of<Transactionprovider>(
                                                        context,
                                                        listen: false)
                                                    .unpaidModel
                                                    .response[0]
                                                    .bookingId,
                                                Provider.of<Transactionprovider>(
                                                            context,
                                                            listen: false)
                                                        .amount *
                                                    100,
                                                Provider.of<Omiseprovider>(
                                                        context,
                                                        listen: false)
                                                    .sourceModel
                                                    .id,
                                              )
                                              .then((value) => {
                                                    if (value == true)
                                                      {
                                                        print(
                                                          Provider.of<Transactionprovider>(
                                                                  context,
                                                                  listen: false)
                                                              .unpaidModel
                                                              .response[0]
                                                              .bookingId,
                                                        ),
                                                        print(Provider.of<
                                                                    Transactionprovider>(
                                                                context,
                                                                listen: false)
                                                            .amount),

                                                        Provider.of<Transactionprovider>(
                                                                context,
                                                                listen: false)
                                                            .paymentAPI(
                                                                Provider.of<Transactionprovider>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .unpaidModel
                                                                    .response[0]
                                                                    .bookingId,
                                                                Provider.of<Transactionprovider>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .amount)
                                                            .then((value) => {
                                                                  if (value ==
                                                                      true)
                                                                    {
                                                                      Provider.of<Transactionprovider>(context, listen: false).qrinfoOut = '{"bookingId": ' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .unpaidModel
                                                                              .response[
                                                                                  0]
                                                                              .bookingId
                                                                              .toString() +
                                                                          ', "chkDatetime": "' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .CheckoutTime
                                                                              .toString() +
                                                                          '", "status": "out", "lotId": ' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .unpaidModel
                                                                              .response[0]
                                                                              .lotId
                                                                              .toString() +
                                                                          ' }',
                                                                      Navigator.pop(
                                                                          context),
                                                                      Navigator
                                                                          .push(
                                                                        context,
                                                                        MaterialPageRoute(
                                                                          builder:
                                                                              (context) {
                                                                            return QrScreenn();
                                                                          },
                                                                        ),
                                                                      ),
                                                                    }
                                                                })

                                                        // Provider.of<Transactionprovider>(
                                                        //         context,
                                                        //         listen: false)
                                                        //     .paymentAPI(
                                                        //         Provider.of<Transactionprovider>(
                                                        //                 context,
                                                        //                 listen:
                                                        //                     false)
                                                        //             .unpaidModel
                                                        //             .response[0]
                                                        //             .bookingId,
                                                        //   Provider.of<Transactionprovider>(
                                                        //       context,
                                                        //       listen: false)
                                                        //   .amount)
                                                        //     .then((value) => {
                                                        //           if (value ==
                                                        //               true)
                                                        //             {
                                                        //               Navigator.pop(
                                                        //                   context),
                                                        //               Navigator
                                                        //                   .push(
                                                        //                 context,
                                                        //                 MaterialPageRoute(
                                                        //                   builder:
                                                        //                       (context) {
                                                        //                     return QrScreenn();
                                                        //                   },
                                                        //                 ),
                                                        //               ),
                                                        //             }
                                                        //         })
                                                        //
                                                        //
                                                        // print('CHARGES'),
                                                        // print(Provider.of<
                                                        //             Omiseprovider>(
                                                        //         context,
                                                        //         listen: false)
                                                        //     .chargesModel
                                                        //     .id),
                                                      }
                                                  })
                                          // Navigator.pop(context),
                                          // Navigator.push(
                                          //   context,
                                          //   MaterialPageRoute(
                                          //     builder: (context) {
                                          //       return QrScreenn();
                                          //     },
                                          //   ),
                                          // ),
                                        }
                                    });
                          })
                        ..show();
                    },
                  ),
                  FlatButton(
                    padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
                    child: Text("Cancel",
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    textColor: K,
                    color: Colors.white,
                    shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white, width: 3),
                        borderRadius: BorderRadius.circular(10)),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) {
                            return MenuScreen();
                          },
                        ),
                      );
                    },
                  ),
                ],
              ),
            ))
          ],
        ),
      ),
    );
  }
}
