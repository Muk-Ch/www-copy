import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Krungsri/bocon.dart';



class KrungsriconScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      
      
      body: Body(),
      
    );
    
  }
}
