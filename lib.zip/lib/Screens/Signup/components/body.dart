import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/login_screen.dart';
import 'package:flutter_auth/Screens/Signup/components/background.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/components/Email.dart';
import 'package:flutter_auth/components/pass.dart';
import 'package:flutter_auth/components/phone.dart';
import 'package:flutter_auth/components/user.dart';
import 'package:flutter_auth/provider/Userporvider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  String usernameText;
  String passwordText;
  String emailText;
  String phonenoText;

  void _validate() {
    if (usernameText == null || usernameText == '') {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input username.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
    } else if (passwordText == null || passwordText == '') {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input password.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
    } else if (emailText == null ||
        emailText == '' ||
        emailText.contains('@') == false) {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input email.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
    } else if (phonenoText == null || phonenoText == '') {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input phone number.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
      //print('PHONE NO ERROR');
    } else {
      Provider.of<Userprovider>(context, listen: false)
          .sign(usernameText, passwordText, emailText, phonenoText)
          .then((value) => {
                if (value == true)
                  {
                    if (Provider.of<Userprovider>(context, listen: false)
                            .signModel
                            .status ==
                        true)
                      {
                        AwesomeDialog(
                            context: context,
                            dialogType: DialogType.SUCCES,
                            headerAnimationLoop: false,
                            animType: AnimType.LEFTSLIDE,
                            title: 'SUCCESSFUL',
                            desc: 'Sign up successful.',
                            btnOkOnPress: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) {
                                    return LoginScreen();
                                  },
                                ),
                              );
                              debugPrint('OnClcik');
                            },
                            btnOkIcon: Icons.check_circle,
                            onDissmissCallback: () {
                              debugPrint('Dialog Dissmiss from callback');
                            })
                          ..show(),
                      }
                    else
                      {
                        print(Provider.of<Userprovider>(context, listen: false)
                            .signModel
                            .status),
                        if (Provider.of<Userprovider>(context, listen: false)
                                .signModel
                                .response ==
                            "Username_UNIQUE")
                          {
                            AwesomeDialog(
                                context: context,
                                animType: AnimType.TOPSLIDE,
                                headerAnimationLoop: false,
                                dialogType: DialogType.WARNING,
                                title: 'DUPLICATE USERNAME',
                                desc: "Please change your username.",
                                btnOkOnPress: () {},
                                btnOkIcon: Icons.check_circle,
                                onDissmissCallback: () {
                                  debugPrint('Dialog Dissmiss from callback');
                                })
                              ..show()
                          }
                        else if (Provider.of<Userprovider>(context,
                                    listen: false)
                                .signModel
                                .response ==
                            "Email_PhoneNo")
                          {
                            AwesomeDialog(
                                context: context,
                                animType: AnimType.TOPSLIDE,
                                headerAnimationLoop: false,
                                dialogType: DialogType.WARNING,
                                title: 'DUPLICATE EMAIL OR PHONE NUMBER',
                                desc:
                                    "Please change your email or phone number.",
                                btnOkOnPress: () {},
                                btnOkIcon: Icons.check_circle,
                                onDissmissCallback: () {
                                  debugPrint('Dialog Dissmiss from callback');
                                })
                              ..show()
                          }
                        else
                          {
                            print(Provider.of<Userprovider>(context,
                                    listen: false)
                                .signModel
                                .status),
                          }
                      }
                  }
              });
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.15),
            RoundeduserField(
              onChanged: (value) {
                usernameText = value;
              },
            ),
            SizedBox(height: size.height * 0.01),
            RoundedmailField(
              onChanged: (value) {
                emailText = value;
              },
            ),
            SizedBox(height: size.height * 0.01),
            RoundedphoneField(
              onChanged: (value) {
                phonenoText = value;
              },
            ),
            SizedBox(height: size.height * 0.01),
            RoundedpassField(
              onChanged: (value) {
                passwordText = value;
              },
            ),
            SizedBox(height: size.height * 0.04),
            FlatButton(
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              child: Text("SIGN UP",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              textColor: Colors.white,
              color: Colors.black,
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white, width: 3),
                  borderRadius: BorderRadius.circular(10)),
              onPressed: () {
                print(usernameText);
                print(passwordText);
                print(emailText);
                print(phonenoText);

                _validate();
              },
            ),
            SizedBox(height: size.height * 0.01),
            Image.asset(
              "assets/images/IMG_0825.PNG",
              width: size.width * 300,
            ),
          ],
        ),
      ),
    );
  }
}
