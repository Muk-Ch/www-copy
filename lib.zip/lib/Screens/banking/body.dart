import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/banking/background.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/SCB/SCB_Screen.dart';
import 'package:flutter_auth/Screens/Bangkok/Bangkok_Screen.dart';
import 'package:flutter_auth/Screens/Krungthai/Krungthai_Screen.dart';
import 'package:flutter_auth/Screens/Krungsri/Krungsri_Screen.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Container(
                width: 325,
                height: 100,
                child: Card(
                  child: InkWell(
                      highlightColor: H,
                      splashColor: H,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return SCBScreen();
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Image.asset(
                            "assets/images/IMG_1067.PNG",
                            height: 60,
                            width: 60,
                          ),
                          Text(
                            "     SCB Bank             ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black87,
                                fontFamily: "Asap"),
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 40,
                          )
                        ],
                      )),
                )),
            Container(
                width: 325,
                height: 100,
                child: Card(
                  child: InkWell(
                      highlightColor: H,
                      splashColor: H,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return BangkokScreen();
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Image.asset(
                            "assets/images/IMG_1071.PNG",
                            height: 60,
                            width: 60,
                          ),
                          Text(
                            "   Bangkok Bank   ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black87,
                                fontFamily: "Asap"),
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 40,
                          )
                        ],
                      )),
                )),
            Container(
                width: 325,
                height: 100,
                child: Card(
                  child: InkWell(
                      highlightColor: H,
                      splashColor: H,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return KrungthaiScreen();
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Image.asset(
                            "assets/images/IMG_1070.PNG",
                            height: 80,
                            width: 80,
                          ),
                          Text(
                            "   Krungthai Bank   ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black87,
                                fontFamily: "Asap"),
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 40,
                          )
                        ],
                      )),
                )),
            Container(
                width: 325,
                height: 100,
                child: Card(
                  child: InkWell(
                      highlightColor: H,
                      splashColor: H,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) {
                              return KrungsriScreen();
                            },
                          ),
                        );
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: <Widget>[
                          Image.asset(
                            "assets/images/IMG_1076.PNG",
                            height: 60,
                            width: 60,
                          ),
                          Text(
                            "   Krungsri Bank   ",
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 20,
                                color: Colors.black87,
                                fontFamily: "Asap"),
                          ),
                          Icon(
                            Icons.arrow_forward_ios_rounded,
                            size: 40,
                          )
                        ],
                      )),
                )),
            SizedBox(height: size.height * 0.03),
          ],
        ),
      ),
    );
  }
}
