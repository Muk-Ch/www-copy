import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/banking/body.dart';



class BankingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(""),
      ),
      
      body: Body(),
      
    );
    
  }
}
