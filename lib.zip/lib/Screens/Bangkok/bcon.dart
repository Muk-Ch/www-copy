import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class Background extends StatelessWidget {
  final Widget child;
  const Background({
    Key key,
    @required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      height: size.height,
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        
        children: <Widget>[
            Positioned(
             bottom: 700,
              child:Container(
            
            child: Align(
              
              alignment: Alignment.topCenter,
              child: Column(
                children: <Widget>[
                  Image.asset("assets/images/IMG_1071.PNG",
                      height: 60,
                      width: 60,),
                      Padding(padding: EdgeInsets.all(5)),
                      Text("Bangkok Bank",
                      style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 50,
                      color: Colors.black87,
                      fontFamily: "Asap"
                      ),
                      ),
                ],
              )
              ),
              ),),
          
          Positioned(
            top:250,
            child: Container(
              width: 375,
              height: 550,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  width: 5,
                  color: Colors.black26),
                borderRadius: BorderRadius.all(
                  Radius.circular(15)
                ),
                  )
              ),
              ),
             
            
          
          child,
        ],
      ),
    );
  }
}
