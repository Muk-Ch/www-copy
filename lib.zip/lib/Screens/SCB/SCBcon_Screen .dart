import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/SCB/bocon.dart';



class SCBSconcreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      
      
      body: Body(),
      
    );
    
  }
}
