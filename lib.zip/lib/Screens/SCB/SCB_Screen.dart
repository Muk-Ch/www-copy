import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/SCB/body.dart';



class SCBScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(""),
      ),
      
      body: Body(),
      
    );
    
  }
}
