import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Krungsri/Krungsri_Screen.dart';
import 'package:flutter_auth/Screens/Krungthai/background.dart';
import 'package:flutter_auth/Screens/Krungthai/krungthaicon_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/provider/Transactionprovider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    var berFell = DateTime.now();
    var diff = now.difference(berFell);
    var hr = diff.inHours;
    var mi = diff.inMinutes;
    var amount = ((hr * 60) + mi) * (60 / 40);
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            SizedBox(height: size.height * 0.2),
            Text(
              "Your payment",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 25,
                  color: M,
                  fontFamily: "Asap"),
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              child: Center(
                child: Row(
                  children: <Widget>[
                    Text(
                      "          Time in",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          color: Colors.black54,
                          fontFamily: "Asap"),
                    ),
                    Text(
                      "                  " +
                          ((DateTime.parse(Provider.of<Transactionprovider>(
                                          context,
                                          listen: false)
                                      .unpaidModel
                                      .response[0]
                                      .timeIn))
                                  .toLocal())
                              .hour
                              .toString() +
                          " : " +
                          ((DateTime.parse(Provider.of<Transactionprovider>(
                                          context,
                                          listen: false)
                                      .unpaidModel
                                      .response[0]
                                      .timeIn))
                                  .toLocal())
                              .minute
                              .toString() +
                          " : " +
                          ((DateTime.parse(Provider.of<Transactionprovider>(
                                          context,
                                          listen: false)
                                      .unpaidModel
                                      .response[0]
                                      .timeIn))
                                  .toLocal())
                              .second
                              .toString(),
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              child: Center(
                child: Row(
                  children: <Widget>[
                    Text(
                      "          Time out",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          color: Colors.black54,
                          fontFamily: "Asap"),
                    ),
                    Text(
                      "               " +
                          Provider.of<Transactionprovider>(context,
                                  listen: false)
                              .CheckoutTime
                              .toLocal()
                              .hour
                              .toString() +
                          " : " +
                          Provider.of<Transactionprovider>(context,
                                  listen: false)
                              .CheckoutTime
                              .toLocal()
                              .minute
                              .toString() +
                          " : " +
                          Provider.of<Transactionprovider>(context,
                                  listen: false)
                              .CheckoutTime
                              .toLocal()
                              .second
                              .toString(),
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Divider(
              height: 10,
              thickness: 5,
              indent: 40,
              endIndent: 40,
              color: Colors.black26,
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              child: Center(
                child: Row(
                  children: <Widget>[
                    Text(
                      "          Total time (hr.)",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          color: Colors.black54,
                          fontFamily: "Asap"),
                    ),
                    Text(
                      '           ' +
                          (Provider.of<Transactionprovider>(context,
                                          listen: false)
                                      .total ~/
                                  60)
                              .toString() +
                          " : " +
                          (Provider.of<Transactionprovider>(context,
                                          listen: false)
                                      .total %
                                  60)
                              .toString(),
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: size.height * 0.03),
            Container(
              child: Center(
                child: Row(
                  children: <Widget>[
                    Text(
                      "          Amount (THB)",
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                          color: Colors.black54,
                          fontFamily: "Asap"),
                    ),
                    Text(
                      '            ' +
                          Provider.of<Transactionprovider>(context,
                                  listen: false)
                              .amount
                              .toString(),
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.black,
                          fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: size.height * 0.09),
            FlatButton(
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              child: Text("Pay",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              textColor: Colors.white,
              color: M,
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white, width: 3),
                  borderRadius: BorderRadius.circular(10)),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return KrungthaiconScreen();
                    },
                  ),
                );
                //       showDialog(
                //    context: context,
                //    builder: (context){
                //      return AlertDialog(
                //     title: Text('QR Code',
                //    style: TextStyle(
                //       fontWeight: FontWeight.bold,
                //       fontSize: 30,
                //       color: Colors.indigo.shade900,
                //       fontFamily: "Asap"
                //         ),
                //          ),
                //    content: Text('   QR code for open the gate will be counted immedietly after confirm button pressed.\n   To prevent qr code expired please press confirm button at the gate.',

                //    style: TextStyle(
                //       fontWeight: FontWeight.bold,
                //       fontSize: 20,
                //       color: Colors.black,
                //       fontFamily: "Asap"
                //         ),
                //          ),

                //    actions: [
                //       FlatButton(
                //         child: Text('OK',
                //         style: TextStyle(
                //       fontWeight: FontWeight.bold,
                //       fontSize: 17,
                //       color: Colors.blue,
                //       fontFamily: "Asap"
                //         ),
                //          ),
                //         onPressed: () {
                //     Navigator.push(
                //     context,
                //     MaterialPageRoute(
                //       builder: (context) {
                //          return KrungthaiconScreen();
                //       },
                //     ),
                //   );
                // },)
                //    ],
                //  );
                //    },
                //    );
              },
            ),
          ],
        ),
      ),
    );
  }
}
