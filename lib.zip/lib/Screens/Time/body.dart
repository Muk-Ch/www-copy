import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/qr_code_in/qr_screen.dart';
import 'package:flutter_auth/Screens/Time/background.dart';
import 'package:flutter_auth/Screens/qr_code_out/qr_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/provider/Bookingprovider.dart';
import 'package:flutter_auth/provider/Lotsprovider.dart';
import 'package:flutter_auth/provider/Userporvider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var now = DateTime.now();
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.02),
            Text(
              "PARKING RESERVATION",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: G,
                  fontFamily: 'Asap'),
            ),
            Text(
              "SYSTEM",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  color: G,
                  fontFamily: 'Asap'),
            ),
            Positioned(
              top: 0,
              child: Container(
                width: 400,
                height: 230,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('assets/images/time.PNG')),
                ),
              ),
            ),
            SizedBox(height: size.height * 0.003),
            Padding(
                padding: EdgeInsetsDirectional.fromSTEB(50, 12, 12, 12),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "Parking space available ",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        fontFamily: 'Asap',
                        letterSpacing: 0.5),
                  ),
                )),
            Container(
              width: 300,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(width: 5, color: Colors.black),
                borderRadius: BorderRadius.all(Radius.circular(5)),
              ),
              child: Center(
                  child: Text(
                Provider.of<Lotsprovider>(context, listen: false)
                    .lotsModel
                    .response
                    .length
                    .toString(),
                style: TextStyle(
                    fontSize: 20, color: A, fontWeight: FontWeight.bold),
              )),
            ),
            SizedBox(height: size.height * 0.02),
            Padding(
                padding: EdgeInsetsDirectional.fromSTEB(50, 12, 12, 12),
                child: Align(
                  alignment: Alignment.bottomLeft,
                  child: Text(
                    "Date",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        fontFamily: 'Asap',
                        letterSpacing: 0.5),
                  ),
                )),
            Container(
              width: 300,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(width: 5, color: Colors.black),
                borderRadius: BorderRadius.all(Radius.circular(5)),
              ),
              child: Center(
                  child: Text(
                '${now.day} / ${now.month} / ${now.year}',
                style: TextStyle(
                    fontSize: 20, color: A, fontWeight: FontWeight.bold),
              )),
            ),
            SizedBox(height: size.height * 0.02),
            SizedBox(height: size.height * 0.15),
            FlatButton(
              padding: EdgeInsets.symmetric(vertical: 20, horizontal: 40),
              child: Text("Confirm",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              textColor: Colors.white,
              color: G,
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white, width: 3),
                  borderRadius: BorderRadius.circular(10)),
              onPressed: () {
                AwesomeDialog(
                    context: context,
                    dialogType: DialogType.WARNING,
                    headerAnimationLoop: false,
                    animType: AnimType.TOPSLIDE,
                    showCloseIcon: true,
                    closeIcon: Icon(Icons.close_fullscreen_outlined),
                    title: 'QR Code',
                    desc:
                        'QR code for open the gate will be counted immedietly after confirm button pressed.\nTo prevent qr code expired please press confirm button at the gate.',
                    btnCancelOnPress: () {},
                    btnOkOnPress: () {
                      showDialog(
                          context: context,
                          builder: (_) => new CupertinoAlertDialog(
                                title: new Text("Waiting"),
                                content: new Text(
                                    "Sending infomation. Please wait."),
                              ));
                      print(Provider.of<Lotsprovider>(context, listen: false)
                          .lotsModel
                          .response[0]
                          .lotId);
                      print(Provider.of<Userprovider>(context, listen: false)
                          .loginModel
                          .response[0]
                          .userId);
                      Provider.of<Bookingprovider>(context, listen: false)
                          .bookingAPI(
                              Provider.of<Lotsprovider>(context, listen: false)
                                  .lotsModel
                                  .response[0]
                                  .lotId,
                              Provider.of<Userprovider>(context, listen: false)
                                  .loginModel
                                  .response[0]
                                  .userId)
                          .then((value) => {
                                if (value == true)
                                  {
                                    Provider.of<Bookingprovider>(context,
                                                listen: false)
                                            .qrinfoIn =
                                        '{"bookingId": ' +
                                            Provider.of<Bookingprovider>(
                                                    context,
                                                    listen: false)
                                                .bookingsModel
                                                .response[0]
                                                .bookingId
                                                .toString() +
                                            ', "chkDatetime": "' +
                                            Provider.of<Bookingprovider>(
                                                    context,
                                                    listen: false)
                                                .bookingsModel
                                                .response[0]
                                                .bookingDatetime
                                                .toString() +
                                            '", "status": "in"}',
                                    Navigator.pop(context),
                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) {
                                          return QrScreen();
                                        },
                                      ),
                                    ),
                                    print(Provider.of<Bookingprovider>(context,
                                            listen: false)
                                        .bookingsModel
                                        .response[0]
                                        .bookingId),
                                    print(Provider.of<Bookingprovider>(context,
                                            listen: false)
                                        .bookingsModel
                                        .response[0]
                                        .bookingDatetime),
                                  }
                              });
                    })
                  ..show();
              },
            ),
          ],
        ),
      ),
    );
  }
}
