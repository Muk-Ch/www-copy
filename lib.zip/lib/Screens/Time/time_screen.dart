import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Time/body.dart';



class TimeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Time"),
      ),
      body: Body(),
      
    );
    
  }
}
