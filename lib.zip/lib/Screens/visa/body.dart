import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/Screens/qr_code_in/qr_screen.dart';
import 'package:flutter_auth/Screens/qr_code_out/qr_screen.dart';
import 'package:flutter_auth/Screens/visa/visa_screen.dart';
import 'package:flutter_auth/provider/Bookingprovider.dart';
import 'package:flutter_auth/provider/Historyprovider.dart';
import 'package:flutter_auth/provider/Omiseprovider.dart';
import 'package:flutter_auth/provider/Transactionprovider.dart';
import 'package:flutter_credit_card/credit_card_form.dart';
import 'package:flutter_credit_card/credit_card_model.dart';
import 'package:flutter_credit_card/flutter_credit_card.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

void main() => runApp(MySample());

class MySample extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MySampleState();
  }
}

class MySampleState extends State<MySample> {
  String cardNumber = '';
  String expiryDate = '';
  String cardHolderName = '';
  String cvvCode = '';
  bool isCvvFocused = false;
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Credit Card View Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Column(
            children: <Widget>[
              CreditCardWidget(
                cardNumber: cardNumber,
                expiryDate: expiryDate,
                cardHolderName: cardHolderName,
                cvvCode: cvvCode,
                showBackView: isCvvFocused,
                obscureCardNumber: true,
                obscureCardCvv: true,
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      CreditCardForm(
                        formKey: formKey,
                        obscureCvv: true,
                        obscureNumber: true,
                        cardNumber: cardNumber,
                        cvvCode: cvvCode,
                        cardHolderName: cardHolderName,
                        expiryDate: expiryDate,
                        themeColor: Colors.blue,
                        cardNumberDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Number',
                          hintText: 'XXXX XXXX XXXX XXXX',
                        ),
                        expiryDateDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Expired Date',
                          hintText: 'XX/XX',
                        ),
                        cvvCodeDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'CVV',
                          hintText: 'XXX',
                        ),
                        cardHolderDecoration: const InputDecoration(
                          border: OutlineInputBorder(),
                          labelText: 'Card Holder',
                        ),
                        onCreditCardModelChange: onCreditCardModelChange,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8.0),
                            ),
                            primary: const Color(0xff1b447b),
                          ),
                          child: Container(
                            padding: EdgeInsets.all(10),
                            margin: const EdgeInsets.all(10),
                            child: Text(
                              'PAY NOW ' +
                                  Provider.of<Transactionprovider>(context,
                                          listen: false)
                                      .amount
                                      .toString() +
                                  ' THB',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'halter',
                                fontSize: 18,
                                package: 'flutter_credit_card',
                              ),
                            ),
                          ),
                          onPressed: () {
                            // print(cardNumber);
                            // print(cvvCode);
                            // print(cardHolderName);
                            // print(expiryDate);
                            showDialog(
                                context: context,
                                builder: (_) => new CupertinoAlertDialog(
                                      title: new Text("Waiting"),
                                      content: new Text(
                                          "Processing... Please wait."),
                                    ));

                            Provider.of<Omiseprovider>(context, listen: false)
                                .cardName = cardHolderName;
                            Provider.of<Omiseprovider>(context, listen: false)
                                .cardNumber = cardNumber;
                            Provider.of<Omiseprovider>(context, listen: false)
                                .cardCode = cvvCode;
                            Provider.of<Omiseprovider>(context, listen: false)
                                .cardExpired = expiryDate.split('/');

                            print(Provider.of<Omiseprovider>(context,
                                    listen: false)
                                .cardName);
                            print(Provider.of<Omiseprovider>(context,
                                    listen: false)
                                .cardNumber);
                            print(Provider.of<Omiseprovider>(context,
                                    listen: false)
                                .cardCode);
                            print((int.parse(Provider.of<Omiseprovider>(context,
                                        listen: false)
                                    .cardExpired[0]))
                                .toString());
                            print(Provider.of<Omiseprovider>(context,
                                    listen: false)
                                .cardExpired[1]);

                            Provider.of<Omiseprovider>(context, listen: false)
                                .tokensAPI()
                                .then((value) => {
                                      if (value == true)
                                        {
                                          print('TOKEN'),
                                          print(Provider.of<Omiseprovider>(
                                                  context,
                                                  listen: false)
                                              .tokensModel
                                              .id),
                                          Provider.of<Omiseprovider>(context,
                                                  listen: false)
                                              .chargeAPI(
                                                  Provider.of<Transactionprovider>(
                                                          context,
                                                          listen: false)
                                                      .unpaidModel
                                                      .response[0]
                                                      .bookingId,
                                                  Provider.of<Transactionprovider>(
                                                              context,
                                                              listen: false)
                                                          .amount *
                                                      100,
                                                  Provider.of<Omiseprovider>(
                                                          context,
                                                          listen: false)
                                                      .tokensModel
                                                      .id)
                                              .then((value) => {
                                                    if (value == true)
                                                      {
                                                        print(
                                                          Provider.of<Transactionprovider>(
                                                                  context,
                                                                  listen: false)
                                                              .unpaidModel
                                                              .response[0]
                                                              .bookingId,
                                                        ),
                                                        print(Provider.of<
                                                                    Transactionprovider>(
                                                                context,
                                                                listen: false)
                                                            .amount),

                                                        Provider.of<Transactionprovider>(
                                                                context,
                                                                listen: false)
                                                            .paymentAPI(
                                                                Provider.of<Transactionprovider>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .unpaidModel
                                                                    .response[0]
                                                                    .bookingId,
                                                                Provider.of<Transactionprovider>(
                                                                        context,
                                                                        listen:
                                                                            false)
                                                                    .amount)
                                                            .then((value) => {
                                                                  if (value ==
                                                                      true)
                                                                    {
                                                                      Provider.of<Transactionprovider>(context, listen: false).qrinfoOut = '{"bookingId": ' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .unpaidModel
                                                                              .response[
                                                                                  0]
                                                                              .bookingId
                                                                              .toString() +
                                                                          ', "chkDatetime": "' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .CheckoutTime
                                                                              .toString() +
                                                                          '", "status": "out", "lotId": ' +
                                                                          Provider.of<Transactionprovider>(context, listen: false)
                                                                              .unpaidModel
                                                                              .response[0]
                                                                              .lotId
                                                                              .toString() +
                                                                          ' }',
                                                                      Navigator.pop(
                                                                          context),
                                                                      Navigator
                                                                          .push(
                                                                        context,
                                                                        MaterialPageRoute(
                                                                          builder:
                                                                              (context) {
                                                                            return QrScreenn();
                                                                          },
                                                                        ),
                                                                      ),
                                                                    }
                                                                })

                                                        // Provider.of<Transactionprovider>(
                                                        //         context,
                                                        //         listen: false)
                                                        //     .paymentAPI(
                                                        //         Provider.of<Transactionprovider>(
                                                        //                 context,
                                                        //                 listen:
                                                        //                     false)
                                                        //             .unpaidModel
                                                        //             .response[0]
                                                        //             .bookingId,
                                                        //   Provider.of<Transactionprovider>(
                                                        //       context,
                                                        //       listen: false)
                                                        //   .amount)
                                                        //     .then((value) => {
                                                        //           if (value ==
                                                        //               true)
                                                        //             {
                                                        //               Navigator.pop(
                                                        //                   context),
                                                        //               Navigator
                                                        //                   .push(
                                                        //                 context,
                                                        //                 MaterialPageRoute(
                                                        //                   builder:
                                                        //                       (context) {
                                                        //                     return QrScreenn();
                                                        //                   },
                                                        //                 ),
                                                        //               ),
                                                        //             }
                                                        //         })
                                                        //
                                                        //
                                                        // print('CHARGES'),
                                                        // print(Provider.of<
                                                        //             Omiseprovider>(
                                                        //         context,
                                                        //         listen: false)
                                                        //     .chargesModel
                                                        //     .id),
                                                      }
                                                  })
                                        }
                                    });
                            //
                            //
                            //             Alert(
                            //   context: context,
                            //   type: AlertType.warning,
                            //   title: "QR Code",
                            //   desc:
                            //         "QR code for open the gate will be counted immedietly after OK button pressed.\nTo prevent qr code expired please press OK button at the gate.",
                            //   buttons: [
                            //     DialogButton(
                            //         child: Text(
                            //           "OK",
                            //           style: TextStyle(color: Colors.white, fontSize: 20),
                            //         ),
                            //         onPressed: () {
                            //           Navigator.push(
                            //             context,
                            //             MaterialPageRoute(
                            //               builder: (context) {
                            //                 return VisaScreen();
                            //               },
                            //             ),
                            //           );
                            //         },
                            //         color: Colors.black,
                            //         radius: BorderRadius.circular(0.0),
                            //     ),
                            //     DialogButton(
                            //         child: Text(
                            //           "CANCEL",
                            //           style: TextStyle(color: Colors.black, fontSize: 20),
                            //         ),
                            //         onPressed: () {
                            //           Navigator.push(
                            //             context,
                            //             MaterialPageRoute(
                            //               builder: (context) {
                            //                 return QrScreenn();
                            //               },
                            //             ),
                            //           );
                            //         },
                            //         color: Colors.grey,
                            //         radius: BorderRadius.circular(0.0),
                            //     ),
                            //   ],
                            // ).show();

                            //             showDialog(
                            //    context: context,
                            //    builder: (context){
                            //      return AlertDialog(
                            //     title: Text('QR Code',
                            //    style: TextStyle(
                            //       fontWeight: FontWeight.bold,
                            //       fontSize: 30,
                            //       color: Colors.indigo.shade900,
                            //       fontFamily: "Asap"
                            //         ),
                            //          ),
                            //    content: Text('   QR code for open the gate will be counted immedietly after OK button pressed.\n   To prevent qr code expired please press OK button at the gate.',

                            //    style: TextStyle(
                            //       fontWeight: FontWeight.bold,
                            //       fontSize: 20,
                            //       color: Colors.black,
                            //       fontFamily: "Asap"
                            //         ),
                            //          ),

                            //    actions: [
                            //       FlatButton(
                            //         child: Text('Cancle',
                            //         style: TextStyle(
                            //       fontWeight: FontWeight.bold,
                            //       fontSize: 17,
                            //       color: Colors.blue,
                            //       fontFamily: "Asap"
                            //         ),
                            //          ),
                            //         onPressed: () {
                            //     Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //       builder: (context) {
                            //          return VisaScreen();
                            //       },
                            //     ),
                            //   );
                            // },),
                            //     FlatButton(
                            //         child: Text('OK',
                            //         style: TextStyle(
                            //       fontWeight: FontWeight.bold,
                            //       fontSize: 17,
                            //       color: Colors.blue,
                            //       fontFamily: "Asap"
                            //         ),
                            //          ),
                            //         onPressed: () {
                            //     Navigator.push(
                            //     context,
                            //     MaterialPageRoute(
                            //       builder: (context) {
                            //          return QrScreenn();
                            //       },
                            //     ),
                            //   );
                            // },),
                            //    ],
                            //  );
                            //    },
                            //    );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void onCreditCardModelChange(CreditCardModel creditCardModel) {
    setState(() {
      cardNumber = creditCardModel.cardNumber;
      expiryDate = creditCardModel.expiryDate;
      cardHolderName = creditCardModel.cardHolderName;
      cvvCode = creditCardModel.cvvCode;
      isCvvFocused = creditCardModel.isCvvFocused;
    });
  }
}
