import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/qr_code_out/body.dart';



class QrScreenn extends StatelessWidget {
  final String data = "123";
  @override
  Widget build(BuildContext context) {

    return Scaffold(
     
      body: Body(),

    );
    
  }
}
