import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/History/body.dart';

class HisScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("History"),
      ),
      body: Body(),
    );
  }
}
