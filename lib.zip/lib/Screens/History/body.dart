import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/banking/Medthod_Screen.dart';
import 'package:flutter_auth/Screens/History/body.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/visa/visa_screen.dart';
import 'package:flutter_auth/provider/Bookingprovider.dart';
import 'package:flutter_auth/provider/Historyprovider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Container(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            for (var index = 0;
                index <
                    Provider.of<Historyprovider>(context, listen: false)
                        .historyModel
                        .response
                        .length;
                index++)
              Center(
                child: Card(
                  child: InkWell(
                    splashColor: Colors.blue.withAlpha(30),
                    onTap: () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return AlertDialog(
                            title: Text(
                              "BookingID : " +
                                  ((Provider.of<Historyprovider>(context,
                                              listen: false)
                                          .historyModel
                                          .response[index]
                                          .bookingId)
                                      .toString()),
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 30,
                                  color: Colors.indigo.shade900,
                                  fontFamily: "Asap"),
                            ),
                            content: Text(
                              "BookingStatus : " +
                                  ((Provider.of<Historyprovider>(context, listen: false)
                                          .historyModel
                                          .response[index]
                                          .bookingStatus)
                                      .toString()) +
                                  "\nTimeIn : " +
                                  (Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn != null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn).toLocal())
                                          .hour
                                          .toString())
                                      : '') +
                                  ":" +
                                  (Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn != null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn).toLocal())
                                          .minute
                                          .toString())
                                      : '') +
                                  ":" +
                                  (Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn != null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeIn).toLocal())
                                          .second
                                          .toString())
                                      : '')

                                  // "\nTimeIn : " + (Provider.of<Historyprovider>(context, listen: false)
                                  //             .historyModel
                                  //             .response[index]
                                  //             .bookingDatetime != null ?
                                  // (((Provider.of<Historyprovider>(context, listen: false)
                                  //             .historyModel
                                  //             .response[index]
                                  //             .bookingDatetime)
                                  //         .toLocal())
                                  //     .month
                                  //     .toString()) : 'Not checked in yet.')  +
                                  // " : " +
                                  // ((Provider.of<Historyprovider>(context, listen: false)
                                  //             .historyModel
                                  //             .response[index]
                                  //             .bookingDatetime)
                                  //         .toLocal())
                                  //     .year
                                  //     .toString(),
                                  +
                                  "\nTimeOut : " +
                                  (Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeOut != null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeOut).toLocal())
                                          .hour
                                          .toString())
                                      : '') +
                                  ":" +

                                  (Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeOut != null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeOut).toLocal())
                                          .minute
                                          .toString())
                                      : '') +
                                  ":" +
                                  
                                  (Provider.of<Historyprovider>(context, listen: false)
                                              .historyModel
                                              .response[index]
                                              .timeOut !=
                                          null
                                      ? ((DateTime.parse(Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].timeOut).toLocal()).second.toString())
                                      : '') +
                                  "\nPaymentStatus : " +
                                  ((Provider.of<Historyprovider>(context, listen: false).historyModel.response[index].paymentStatus).toString()),
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20,
                                  color: Colors.black,
                                  fontFamily: "Asap"),
                            ),
                            actions: [
                              FlatButton(
                                child: Text(
                                  'OK',
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 17,
                                      color: Colors.blue,
                                      fontFamily: "Asap"),
                                ),
                                onPressed: () {
                                  Navigator.pop(context);
                                },
                              )
                            ],
                          );
                        },
                      );
                    },
                    child: SizedBox(
                      width: 300,
                      height: 100,
                      child: Container(
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Text(
                                ((Provider.of<Historyprovider>(context,
                                                    listen: false)
                                                .historyModel
                                                .response[index]
                                                .bookingDatetime)
                                            .toLocal())
                                        .day
                                        .toString() +
                                    " / " +
                                    ((Provider.of<Historyprovider>(context,
                                                    listen: false)
                                                .historyModel
                                                .response[index]
                                                .bookingDatetime)
                                            .toLocal())
                                        .month
                                        .toString() +
                                    " / " +
                                    ((Provider.of<Historyprovider>(context,
                                                    listen: false)
                                                .historyModel
                                                .response[index]
                                                .bookingDatetime)
                                            .toLocal())
                                        .year
                                        .toString(),
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 25,
                                    color: Colors.black,
                                    fontFamily: "Asap"),
                              ),
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  "BookingID : " +
                                      ((Provider.of<Historyprovider>(context,
                                                  listen: false)
                                              .historyModel
                                              .response[index]
                                              .bookingId)
                                          .toString()),
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20,
                                      color: Colors.black54,
                                      fontFamily: "Asap"),
                                ),
                              )
                            ]),
                      ),
                      // child: Text(
                      //   ((Provider.of<Historyprovider>(context, listen: false)
                      //                   .historyModel
                      //                   .response[0]
                      //                   .bookingDatetime)
                      //               .toLocal())
                      //           .day
                      //           .toString() + " / " +
                      //       ((Provider.of<Historyprovider>(context,
                      //                       listen: false)
                      //                   .historyModel
                      //                   .response[0]
                      //                   .bookingDatetime)
                      //               .toLocal())
                      //           .month
                      //           .toString() + " / " +
                      //       ((Provider.of<Historyprovider>(context,
                      //                       listen: false)
                      //                   .historyModel
                      //                   .response[0]
                      //                   .bookingDatetime)
                      //               .toLocal())
                      //           .year
                      //           .toString(),
                      //   style: TextStyle(
                      //       fontWeight: FontWeight.bold,
                      //       fontSize: 25,
                      //       color: Colors.black,
                      //       fontFamily: "Asap"),
                      // ),
                    ),
                  ),
                ),
              )
            // Container(
            //   height: 60,
            //   width: 60,
            // child: Text(
            //   ((Provider.of<Historyprovider>(context, listen: false)
            //               .historyModel
            //               .response[0]
            //               .bookingDatetime)
            //           .toLocal())
            //       .day
            //       .toString(),
            //   style: TextStyle(
            //       fontWeight: FontWeight.bold,
            //       fontSize: 25,
            //       color: Colors.black,
            //       fontFamily: "Asap"),
            // ),

            // ListView.builder(
            //   itemCount:
            //   Provider.of<Bookingprovider>(context, listen: false)
            //   .bookingsModel
            //   .response[0]
            //   .toString(),itemBuilder: (context, index) {
            //   InkWell(
            //     child: Card(
            //       child: Padding(
            //         padding: const EdgeInsets.all(16.0),
            //         child: Text(
            //           position.toString(),
            //           style: TextStyle(fontSize: 22.0),
            //         ),
            //       ),
            //     ),
            //     onTap: () {},
            //   );
            // }),
            // Container(
            //   width: 325,
            //   height: 100,
            //   decoration: BoxDecoration(
            //     color: Colors.white,
            //     border: Border(
            //       top: BorderSide(color: Colors.black26,width: 5),
            //       left: BorderSide(color: Colors.black26,width: 5),
            //       right: BorderSide(color: Colors.black26,width: 5)),

            //       ),

            //     child: InkWell(
            //     highlightColor: H,
            //     splashColor: H,
            //     onTap: (){Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) {
            //           return VisaScreen();
            //         },
            //       ),
            //     );},
            //     child:Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //       children: <Widget>[
            //           Icon(Icons.credit_card_rounded ,
            //           color: A,
            //           size: 80,),
            //           Text("     Credit card             ",
            //           style: TextStyle(
            //           fontWeight: FontWeight.bold,
            //           fontSize: 20,
            //           color: Colors.black87,
            //           fontFamily: "Asap"
            //           ),
            //           ),
            //           Icon(Icons.arrow_forward_ios_rounded,
            //           size: 40,)
            //       ],
            //     )
            //   ),
            //   ),

            //   Container(
            //   width: 325,
            //   height: 100,
            //   decoration: BoxDecoration(
            //     color: Colors.white,
            //     border: Border(
            //       top: BorderSide(color: Colors.black26,width: 5),
            //       left: BorderSide(color: Colors.black26,width: 5),
            //       right: BorderSide(color: Colors.black26,width: 5),
            //       bottom: BorderSide(color: Colors.black26,width: 5)),

            //       ),

            //     child: InkWell(
            //     highlightColor: H,
            //     splashColor: H,
            //     onTap: (){Navigator.push(
            //       context,
            //       MaterialPageRoute(
            //         builder: (context) {
            //           return BankingScreen();
            //         },
            //       ),
            //     );},
            //     child:Row(
            //       mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //       children: <Widget>[
            //           Icon(Icons.account_balance_rounded,
            //           color: A,
            //           size: 80,),
            //           Text("   Internet banking   ",
            //           style: TextStyle(
            //           fontWeight: FontWeight.bold,
            //           fontSize: 20,
            //           color: Colors.black87,
            //           fontFamily: "Asap"
            //           ),
            //           ),
            //           Icon(Icons.arrow_forward_ios_rounded,
            //           size: 40,)
            //       ],
            //     )
            //   ),
            //   ),

            //   SizedBox(height: size.height * 0.3),
          ],
        ),
      ),
    );
  }
}
