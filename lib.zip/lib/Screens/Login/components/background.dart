import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';

class Background extends StatelessWidget {
  final Widget child;
  const Background({
    Key key,
    @required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: double.infinity,
      height: size.height,
      child: Stack(
        alignment: Alignment.center,
        children: <Widget>[
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              "assets/images/login.jpg",
              height: 350,
              width: 250,
            ),
          ),
          Positioned(
            bottom: 30,
            
            child: Container(
              width: 400,
              height: 540,
              decoration: BoxDecoration(
                color: Colors.white,
                border: Border.all(
                  width: 5,
                  color: D),
                borderRadius: BorderRadius.all(
                  Radius.circular(40)
                ),
                  )
              ),
            ),
            // Positioned(
            //   bottom: 140,
            
            //     child: Container(
            //     width: 30,
            //     height: 30,
            //     decoration: ShapeDecoration(
            //     color: Colors.black,
            //     shape: CircleBorder()
            //     ),
            //   ),
            // ),

            
          child,

      

        ],
      ),
    );
  }
}
