import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/Login/components/background.dart';
import 'package:flutter_auth/Screens/Signup/signup_screen.dart';
import 'package:flutter_auth/components/already_have_an_account_acheck.dart';
import 'package:flutter_auth/components/rounded_button.dart';
import 'package:flutter_auth/components/rounded_password_field.dart';
import 'package:flutter_auth/components/login.dart';
import 'package:flutter_auth/Screens/menu/menu_screen.dart';
import 'package:flutter_auth/provider/Userporvider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  String usernameText;
  String passwordText;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.40),
            Text(
              "LOGIN",
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 30,
                  fontFamily: "Asap"),
            ),
            SizedBox(height: size.height * 0.02),
            RoundedloginField(
              onChanged: (value) {
                usernameText = value;
              },
            ),
            RoundedPasswordField(
              onChanged: (value) {
                passwordText = value;
              },
            ),
            RoundedButton(
              text: "LOGIN",
              press: () {
                print(usernameText);
                print(passwordText);
                _validate();
                // Provider.of<Userprovider>(context, listen: false)
                //     .login(usernameText, passwordText)
                //     .then((value) => {
                //           if (value == true)
                //             {
                //               if (Provider.of<Userprovider>(context,
                //                           listen: false)
                //                       .loginModel
                //                       .length ==
                //                   1)
                //                 {
                //                   Navigator.push(
                //                     context,
                //                     MaterialPageRoute(
                //                       builder: (context) {
                //                         return MenuScreen();
                //                       },
                //                     ),
                //                   )
                //                 }
                //               else
                //                 {
                //                   print(Provider.of<Userprovider>(context,
                //                           listen: false)
                //                       .loginModel
                //                       .length),
                //                   Alert(
                //                     context: context,
                //                     type: AlertType.error,
                //                     title: "ERROR",
                //                     desc:
                //                         "Please change your username or password.",
                //                     buttons: [
                //                       DialogButton(
                //                         child: Text(
                //                           "OK",
                //                           style: TextStyle(
                //                               color: Colors.white,
                //                               fontSize: 20),
                //                         ),
                //                         onPressed: () => Navigator.pop(context),
                //                         color: Colors.black,
                //                         radius: BorderRadius.circular(0.0),
                //                       ),
                //                     ],
                //                   ).show(),
                //                 }
                //             }
                //         });
              },
            ),
            SizedBox(height: size.height * 0.03),
            AlreadyHaveAnAccountCheck(
              press: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return SignUpScreen();
                    },
                  ),
                );
              },
            ),
            SizedBox(height: size.height * 1),
          ],
        ),
      ),
    );
  }

  void _validate() {
    if (usernameText == null || usernameText == '') {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input username.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
    } else if (passwordText == null || passwordText == '') {
      AwesomeDialog(
          context: context,
          dialogType: DialogType.ERROR,
          headerAnimationLoop: false,
          animType: AnimType.RIGHSLIDE,
          closeIcon: Icon(Icons.close_fullscreen_outlined),
          title: 'ERROR',
          desc: 'Please input password.',
          btnOkOnPress: () {},
          btnOkIcon: Icons.cancel,
          btnOkColor: Colors.red)
        ..show();
    } else {
      Provider.of<Userprovider>(context, listen: false)
          .login(usernameText, passwordText)
          .then((value) => {
                if (value == true)
                  {
                    if (Provider.of<Userprovider>(context, listen: false)
                            .loginModel
                            .length ==
                        1)
                      {
                        AwesomeDialog(
                            context: context,
                            dialogType: DialogType.SUCCES,
                            headerAnimationLoop: false,
                            animType: AnimType.LEFTSLIDE,
                            title: 'SUCCESSFUL',
                            desc: 'Login successful.',
                            btnOkOnPress: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) {
                                    return MenuScreen();
                                  },
                                ),
                              );
                              debugPrint('OnClcik');
                            },
                            btnOkIcon: Icons.check_circle,
                            onDissmissCallback: () {
                              debugPrint('Dialog Dissmiss from callback');
                            })
                          ..show(),
                      },
                  }
                else
                  {
                    print(Provider.of<Userprovider>(context, listen: false)
                        .loginModel
                        .length),
                        {
                    AwesomeDialog(
                        context: context,
                        dialogType: DialogType.ERROR,
                        headerAnimationLoop: false,
                        animType: AnimType.RIGHSLIDE,
                        closeIcon: Icon(Icons.close_fullscreen_outlined),
                        title: 'ERROR',
                        desc: 'Incorrect username or password.',
                        btnOkOnPress: () {},
                        btnOkIcon: Icons.cancel,
                        btnOkColor: Colors.red)
                      ..show()
                    // Alert(
                    //   context: context,
                    //   type: AlertType.error,
                    //   title: "ERROR",
                    //   desc: "Incorrect username or password.",
                    //   buttons: [
                    //     DialogButton(
                    //       child: Text(
                    //         "OK",
                    //         style: TextStyle(color: Colors.white, fontSize: 20),
                    //       ),
                    //       onPressed: () => Navigator.pop(context),
                    //       color: Colors.black,
                    //       radius: BorderRadius.circular(0.0),
                    //     ),
                    //   ],
                    // ).show(),
                        }
                  }
                  
              });
    }
  }
}
