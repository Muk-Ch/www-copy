

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_auth/Screens/History/his_screen.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/Time/time_screen.dart';
import 'package:flutter_auth/Screens/total/total_screen.dart';
import 'package:flutter_auth/provider/Historyprovider.dart';
import 'package:flutter_auth/provider/Lotsprovider.dart';
import 'package:flutter_auth/provider/Transactionprovider.dart';
import 'package:flutter_auth/provider/Userporvider.dart';
import 'package:provider/provider.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return ListView(
      children: <Widget>[
        SizedBox(height: size.height * 0.02),
        Center(
          child: Text(
            "MENU",
            style: TextStyle(
                fontWeight: FontWeight.bold, fontSize: 40, fontFamily: "Asap"),
          ),
        ),
        SizedBox(height: size.height * 0.02),
        Container(
          padding: EdgeInsets.all(15),
          child: Center(
              child: Row(
            children: <Widget>[
              InkWell(
                highlightColor: H,
                splashColor: H,
                onTap: () {
                  Provider.of<Lotsprovider>(context, listen: false)
                      .lots()
                      .then((value) => {
                            if (value == true)
                              {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) {
                                      return TimeScreen();
                                    },
                                  ),
                                ),
                              }
                          });
                },
                child: Container(
                  width: 200,
                  height: 205,
                  decoration: BoxDecoration(
                      border: Border.all(width: 5, color: H),
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image: AssetImage("assets/images/booking.PNG"))),
                ),
              ),
              Text(
                "   Booking",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                    color: B,
                    fontFamily: "Asap"),
              ),
            ],
          )),
        ),
        Container(
          padding: EdgeInsets.all(15),
          child: Center(
              child: Row(
            children: <Widget>[
              InkWell(
                highlightColor: H,
                splashColor: H,
                onTap: () {
                  showDialog(
                      context: context,
                      builder: (_) => new CupertinoAlertDialog(
                            title: new Text("Waiting"),
                            content:
                                new Text("Fetching infomation. Please wait."),
                          ));
                  Provider.of<Transactionprovider>(context, listen: false)
                      .CheckoutTime = DateTime.now();

                  // Provider.of<Transactionprovider>(context, listen: false)
                  //         .total =
                  //     Provider.of<Transactionprovider>(context, listen: false)
                  //         .CheckoutTime
                  //         .difference(DateTime.parse(
                  //             Provider.of<Transactionprovider>(context,
                  //                     listen: false)
                  //                 .unpaidModel
                  //                 .response[0]
                  //                 .timeIn))
                  //         .inMinutes;

                  // Provider.of<Transactionprovider>(context, listen: false)
                  //     .amount = ((Provider.of<Transactionprovider>(context,
                  //                     listen: false)
                  //                 .total ~/
                  //             60) *
                  //         40) +
                  //     ((Provider.of<Transactionprovider>(context, listen: false)
                  //                 .total %
                  //             60) *
                  //         1);
                  // print(Provider.of<Userprovider>(context, listen: false)
                  //     .loginModel
                  //     .response[0]
                  //     .userId);
                  Provider.of<Transactionprovider>(context, listen: false)
                      .unpaidAPI(
                          Provider.of<Userprovider>(context, listen: false)
                              .loginModel
                              .response[0]
                              .userId)
                      .then((value) => {
                            if (value == true)
                              {
                                Provider.of<Transactionprovider>(context,
                                        listen: false)
                                    .total = Provider.of<Transactionprovider>(
                                        context,
                                        listen: false)
                                    .CheckoutTime
                                    .difference(DateTime.parse(
                                        Provider.of<Transactionprovider>(
                                                context,
                                                listen: false)
                                            .unpaidModel
                                            .response[0]
                                            .timeIn))
                                    .inMinutes,
                                Provider.of<Transactionprovider>(context,
                                            listen: false)
                                        .amount =
                                    ((Provider.of<Transactionprovider>(context,
                                                        listen: false)
                                                    .total ~/
                                                60) *
                                            40) +
                                        ((Provider.of<Transactionprovider>(
                                                        context,
                                                        listen: false)
                                                    .total %
                                                60) *
                                            1),
                                print(Provider.of<Userprovider>(context,
                                        listen: false)
                                    .loginModel
                                    .response[0]
                                    .userId),
                                print('----TOTAL TIME-----'),
                                print(Provider.of<Transactionprovider>(context,
                                        listen: false)
                                    .total),
                                Navigator.pop(context),
                                print(Provider.of<Transactionprovider>(context,
                                        listen: false)
                                    .unpaidModel
                                    .response[0]
                                    .bookingId),
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) {
                                      return TotalScreen();
                                    },
                                  ),
                                ),
                              }
                            else
                              {print("UNPAID IS EMPTY")},
                          });
                },
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //     builder: (context) {
                //       return TotalScreen();
                //     },
                //   ),
                // );

                child: Container(
                  width: 200,
                  height: 205,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(width: 5, color: H),
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image: AssetImage("assets/images/pay.PNG"))),
                ),
              ),
              Text(
                "   Payment",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                    color: B,
                    fontFamily: "Asap"),
              ),
            ],
          )),
        ),
        Container(
          padding: EdgeInsets.all(15),
          child: Center(
              child: Row(
            children: <Widget>[
              InkWell(
                highlightColor: H,
                splashColor: H,
                onTap: () {
                  Provider.of<Historyprovider>(context, listen: false)
                      .historyAPI(
                          Provider.of<Userprovider>(context, listen: false)
                              .loginModel
                              .response[0]
                              .userId)
                      .then((value) => {
                            if (value == true)
                              {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) {
                                      return HisScreen();
                                    },
                                  ),
                                ),
                              }
                          });
                },

                //  Navigator.push(
                //                 context,
                //                 MaterialPageRoute(
                //                   builder: (context) {
                //                     return HisScreen();
                //                   },
                //                 ),
                //               );

                child: Container(
                  width: 200,
                  height: 205,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(width: 5, color: H),
                      borderRadius: BorderRadius.circular(20),
                      image: DecorationImage(
                          image: AssetImage("assets/images/his.PNG"))),
                ),
              ),
              Text(
                "   History",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 30,
                    color: B,
                    fontFamily: "Asap"),
              ),
            ],
          )),
        ),
      ],
    );
  }
}
