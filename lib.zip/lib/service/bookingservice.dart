import 'dart:convert';
import 'package:flutter_auth/main.dart';
import 'package:http/http.dart' as http;


class BookingService {
  int _lotid;
  int _userid;

  BookingService(
    this._lotid,
    this._userid,
  );

  Future<http.Response> bookingAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"LotId": _lotid, "UserId": _userid});

    return http.post(host + '/bookings/booking',
        headers: headers, body: body);
  }
}