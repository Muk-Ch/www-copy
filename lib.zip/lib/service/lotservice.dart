import 'dart:convert';
import 'package:flutter_auth/main.dart';
import 'package:http/http.dart' as http;


class LotsService {
  
  Future<http.Response> lotAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    
    return http.post(host + '/lots/chk-free-lot',
        headers: headers);
  }
}

