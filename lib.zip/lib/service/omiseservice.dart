import 'dart:convert';
import 'package:flutter_auth/main.dart';
import 'package:http/http.dart' as http;

class TokensService {
  String _cardName;
  String _cardNumber;
  String _cardCode;
  String _cardExpirdMonth;
  String _cardExpiredYear;

  TokensService(this._cardName, this._cardNumber, this._cardCode,
      this._cardExpirdMonth, this._cardExpiredYear);

  // var queryParameters = {
  //   "card[name]": "JOHN DOE",
  //   "card[number]": "4242424242424242",
  //   "card[security_code]": "123",
  //   "card[expiration_month]": "3",
  //   "card[expiration_year]": "2023"
  // };

  Future<http.Response> tokensAPI() {
    String username = 'pkey_test_5n9kjoq8uu4wqfrk3oe';
    String password;
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));
    // print(basicAuth);

    var queryParameters = {
      "card[name]": _cardName,
      "card[number]": _cardNumber,
      "card[security_code]": _cardCode,
      "card[expiration_month]": _cardExpirdMonth,
      "card[expiration_year]": _cardExpiredYear
    };

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'accept': 'application/json',
      'authorization': basicAuth
    };

    var uri = Uri.https('vault.omise.co', '/tokens', queryParameters);

    return http.post(uri, headers: headers);
  }
}

class ChargesService {
  int _bookingId;
  int _amount;
  String _tokenId;

  ChargesService(
    this._bookingId,
    this._amount,
    this._tokenId,
  );

  Future<http.Response> chargeAPI() {
    String username = 'skey_test_5n9kjoq8vjhydq6lb4m';
    String password;
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));

    var queryParameters = {
      "description": "รายการจองที่ " + _bookingId.toString(),
      "amount": _amount.toString(),
      "currency": "thb",
      "card": _tokenId
    };

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'accept': 'application/json',
      'authorization': basicAuth
    };

    print(_bookingId);
    print(_amount);
    print(_tokenId);
    print(queryParameters);

    var uri = Uri.https('api.omise.co', '/charges', queryParameters);

    print(uri);
   return http.post(uri, headers: headers);
  }
}

class SourceService {
  int _bookingId;
  int _amount;
  //String _sourceId;
  String _type;

  SourceService(
    this._bookingId,
    this._amount,
    //this._sourceId,
    this._type,
  );

  Future<http.Response> sourceAPI() {
    String username = 'skey_test_5n9kjoq8vjhydq6lb4m';
    String password;
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));

    var queryParameters = {
      "description": "รายการจองที่ " + _bookingId.toString(),
      "amount": _amount.toString(),
      "currency": "thb",
      "type": _type
    };

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'accept': 'application/json',
      'authorization': basicAuth
    };

    print(_bookingId);
    print(_amount);
    //print(_sourceId);
    print(queryParameters);

    var uri = Uri.https('api.omise.co', '/sources', queryParameters);

    print(uri);
   return http.post(uri, headers: headers);
  }
}

class BankService {
  int _bookingId;
  int _amount;
  String _sourceId;


  BankService(
    this._bookingId,
    this._amount,
    this._sourceId,    
  );

  Future<http.Response> bankAPI() {
    String username = 'skey_test_5n9kjoq8vjhydq6lb4m';
    String password;
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));

    var queryParameters = {
      "description": "รายการจองที่ " + _bookingId.toString(),
      "amount": _amount.toString(),
      "currency": "thb",
      "source": _sourceId,
      "return_uri":"http://www.example.com" 
    };

    Map<String, String> headers = {
      'Content-Type': 'application/json',
      'accept': 'application/json',
      'authorization': basicAuth
    };

    print(_bookingId);
    print(_amount);
    print(_sourceId);
    print(queryParameters);

    var uri = Uri.https('api.omise.co', '/charges', queryParameters);

    print(uri);
   return http.post(uri, headers: headers);
  }
}
