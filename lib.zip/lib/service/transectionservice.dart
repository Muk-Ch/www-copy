import 'dart:convert';
import 'dart:ffi';
import 'package:flutter_auth/main.dart';
import 'package:http/http.dart' as http;


class UnpaidService {
  int _userId;

  UnpaidService(
    this._userId,
  );

  Future<http.Response> unpaidAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"UserId": _userId});

    return http.post(host + '/transection/unpaid',
        headers: headers, body: body);
  }
}

class PaymentService {
  int _bookingId;
  int _price;

  PaymentService(
    this._bookingId,
    this._price
  );

  Future<http.Response> paymentAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"BookingId": _bookingId, "Price": _price});

    return http.post(host + '/transection/payment',
        headers: headers, body: body);
  }
}