import 'dart:convert';
import 'package:flutter_auth/main.dart';
import 'package:http/http.dart' as http;


class LoginService {
  String _username;
  String _password;

  LoginService(
    this._username,
    this._password,
  );

  Future<http.Response> loginAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"Username": _username, "Password": _password});

    return http.post(host + '/users/login',
        headers: headers, body: body);
  }
}

class SignService {
  String _username;
  String _password;
  String _email;
  String _phoneno;

  SignService(
    this._username,
    this._password,
    this._email,
    this._phoneno,
  );

  Future<http.Response> signAPI() {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    final body = jsonEncode({"Username": _username, "Password": _password,"Email": _email,"PhoneNo":_phoneno});

    return http.post(host + '/users/sign-up',
        headers: headers, body: body);
  }
}

