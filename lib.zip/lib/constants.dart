import 'package:flutter/material.dart';

const A = Color(0xFF556bf4);
const B = Color(0xFFdb2254);
const C = Color(0xFFE1A3B2);
const D = Color(0xFFe87191);
const E = Color(0xFFFF6787);
const F = Color(0xFFF9A826);
const G = Color(0xFF3F3D56);
const H = Color(0xFF00BCA2);
const I = Color(0xFF4E2A82);
const J = Color(0xFFF5D314);
const K = Color(0xFF73615A);
const L = Color(0xFF003399);
const M = Color(0xFF00A6E6);
const N = Color(0xFF06C755);